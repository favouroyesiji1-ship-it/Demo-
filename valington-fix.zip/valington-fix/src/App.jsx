import { useState, useEffect } from "react";

const properties = [
  {
    id: 1,
    title: "Maitama Executive Villa",
    location: "Maitama, Abuja",
    price: "₦450,000,000",
    beds: 5,
    baths: 6,
    sqft: "680 sqm",
    tag: "For Sale",
    color: "#C9A84C",
    img: "https://images.unsplash.com/photo-1613977257365-aaae5a9817ff?w=600&q=80",
  },
  {
    id: 2,
    title: "Asokoro Garden Court",
    location: "Asokoro, Abuja",
    price: "₦1,200,000/mo",
    beds: 4,
    baths: 4,
    sqft: "420 sqm",
    tag: "For Rent",
    color: "#5C8A6A",
    img: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600&q=80",
  },
  {
    id: 3,
    title: "Guzape Hills Residence",
    location: "Guzape, Abuja",
    price: "₦280,000,000",
    beds: 6,
    baths: 7,
    sqft: "900 sqm",
    tag: "New Listing",
    color: "#8B4A2F",
    img: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=600&q=80",
  },
];

const services = [
  {
    icon: "◈",
    title: "Real Estate Marketing",
    desc: "Strategic positioning and premium marketing campaigns that connect exceptional properties with discerning buyers.",
  },
  {
    icon: "◇",
    title: "Property Management",
    desc: "End-to-end management of residential and commercial assets — maximising returns while protecting your investment.",
  },
  {
    icon: "◉",
    title: "Consultancy",
    desc: "Data-driven advisory on acquisition, valuation, and portfolio strategy tailored to the Abuja market.",
  },
  {
    icon: "◈",
    title: "Development",
    desc: "From land procurement to turnkey delivery, we build landmark developments that define neighbourhoods.",
  },
];

const stats = [
  { value: "12+", label: "Years in Abuja" },
  { value: "₦80B+", label: "Properties Sold" },
  { value: "1,400+", label: "Happy Clients" },
  { value: "96%", label: "Client Retention" },
];

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeService, setActiveService] = useState(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div style={styles.root}>
      <style>{css}</style>

      {/* NAV */}
      <nav style={{ ...styles.nav, ...(scrolled ? styles.navScrolled : {}) }}>
        <div style={styles.navInner}>
          <a href="#" style={styles.logo}>
            <span style={styles.logoV}>V</span>alington
          </a>
          <div style={styles.navLinks}>
            {["Properties", "Services", "About", "Contact"].map((l) => (
              <a key={l} href={`#${l.toLowerCase()}`} style={styles.navLink} className="nav-link">
                {l}
              </a>
            ))}
            <a href="#contact" style={styles.navCta} className="cta-btn">
              Book Consultation
            </a>
          </div>
          <button style={styles.burger} onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? "✕" : "☰"}
          </button>
        </div>
        {menuOpen && (
          <div style={styles.mobileMenu}>
            {["Properties", "Services", "About", "Contact"].map((l) => (
              <a
                key={l}
                href={`#${l.toLowerCase()}`}
                style={styles.mobileLink}
                onClick={() => setMenuOpen(false)}
              >
                {l}
              </a>
            ))}
          </div>
        )}
      </nav>

      {/* HERO */}
      <section style={styles.hero} id="hero">
        <div style={styles.heroBg} />
        <div style={styles.heroOverlay} />
        <div style={styles.heroContent} className="hero-content">
          <p style={styles.heroEyebrow} className="fade-up delay-1">
            Premium Real Estate · Abuja, Nigeria
          </p>
          <h1 style={styles.heroH1} className="fade-up delay-2">
            Where Ambition<br />
            <span style={styles.heroAccent}>Finds Home</span>
          </h1>
          <p style={styles.heroSub} className="fade-up delay-3">
            Valington Homes &amp; Properties Ltd connects visionary clients with
            exceptional properties across Abuja's most coveted addresses.
          </p>
          <div style={styles.heroCtas} className="fade-up delay-4">
            <a href="#properties" style={styles.btnPrimary} className="cta-btn">
              Explore Properties
            </a>
            <a href="#services" style={styles.btnGhost} className="ghost-btn">
              Our Services ↓
            </a>
          </div>
        </div>
        <div style={styles.heroScroll} className="fade-up delay-5">
          <span style={styles.scrollDot} className="scroll-dot" />
          <span style={styles.scrollText}>Scroll</span>
        </div>
      </section>

      {/* STATS STRIP */}
      <div style={styles.statsStrip}>
        {stats.map((s) => (
          <div key={s.label} style={styles.stat}>
            <span style={styles.statValue}>{s.value}</span>
            <span style={styles.statLabel}>{s.label}</span>
          </div>
        ))}
      </div>

      {/* PROPERTIES */}
      <section id="properties" style={styles.section}>
        <div style={styles.sectionInner}>
          <p style={styles.eyebrow}>Featured Listings</p>
          <h2 style={styles.h2}>Curated Properties</h2>
          <div style={styles.grid}>
            {properties.map((p) => (
              <div key={p.id} style={styles.card} className="property-card">
                <div style={{ ...styles.cardImg, backgroundImage: `url(${p.img})` }}>
                  <span style={{ ...styles.cardTag, background: p.color }}>{p.tag}</span>
                </div>
                <div style={styles.cardBody}>
                  <p style={styles.cardLocation}>📍 {p.location}</p>
                  <h3 style={styles.cardTitle}>{p.title}</h3>
                  <p style={styles.cardPrice}>{p.price}</p>
                  <div style={styles.cardMeta}>
                    <span>🛏 {p.beds} Beds</span>
                    <span>🚿 {p.baths} Baths</span>
                    <span>📐 {p.sqft}</span>
                  </div>
                  <button style={styles.cardBtn} className="card-btn">
                    View Details →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" style={styles.servicesBg}>
        <div style={styles.sectionInner}>
          <p style={styles.eyebrowLight}>What We Do</p>
          <h2 style={styles.h2Light}>Our Services</h2>
          <div style={styles.servGrid}>
            {services.map((s, i) => (
              <div
                key={i}
                style={{
                  ...styles.servCard,
                  ...(activeService === i ? styles.servCardActive : {}),
                }}
                className="serv-card"
                onMouseEnter={() => setActiveService(i)}
                onMouseLeave={() => setActiveService(null)}
              >
                <span style={styles.servIcon}>{s.icon}</span>
                <h3 style={styles.servTitle}>{s.title}</h3>
                <p style={styles.servDesc}>{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" style={styles.section}>
        <div style={styles.aboutGrid}>
          <div style={styles.aboutImgWrap}>
            <div style={styles.aboutImg} />
            <div style={styles.aboutBadge}>
              <span style={styles.badgeNum}>12+</span>
              <span style={styles.badgeTxt}>Years of Excellence</span>
            </div>
          </div>
          <div style={styles.aboutText}>
            <p style={styles.eyebrow}>About Valington</p>
            <h2 style={styles.h2}>Built on Trust,<br />Driven by Results</h2>
            <p style={styles.bodyText}>
              Founded in Abuja, Valington Homes &amp; Properties Ltd has grown into
              one of the FCT's most trusted real estate firms. We combine deep
              local knowledge with global standards of service to deliver
              outcomes that exceed expectations — every time.
            </p>
            <p style={styles.bodyText}>
              Whether you're a first-time buyer, a seasoned investor, or a
              corporate client, our team crafts personalised strategies built
              around your goals.
            </p>
            <a href="#contact" style={styles.btnPrimary} className="cta-btn">
              Meet Our Team
            </a>
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" style={styles.contactBg}>
        <div style={styles.sectionInner}>
          <p style={styles.eyebrowLight}>Get in Touch</p>
          <h2 style={styles.h2Light}>Start Your Journey</h2>
          <div style={styles.contactGrid}>
            <div style={styles.contactInfo}>
              <div style={styles.contactItem}>
                <span style={styles.contactIcon}>📍</span>
                <div>
                  <strong style={styles.contactLabel}>Address</strong>
                  <p style={styles.contactVal}>Plot 42, Aminu Kano Crescent,<br />Wuse 2, Abuja — FCT</p>
                </div>
              </div>
              <div style={styles.contactItem}>
                <span style={styles.contactIcon}>📞</span>
                <div>
                  <strong style={styles.contactLabel}>Phone</strong>
                  <p style={styles.contactVal}>+234 (0) 801 234 5678</p>
                </div>
              </div>
              <div style={styles.contactItem}>
                <span style={styles.contactIcon}>✉️</span>
                <div>
                  <strong style={styles.contactLabel}>Email</strong>
                  <p style={styles.contactVal}>hello@valington.com.ng</p>
                </div>
              </div>
            </div>
            <div style={styles.contactForm}>
              <input style={styles.input} placeholder="Full Name" />
              <input style={styles.input} placeholder="Email Address" />
              <input style={styles.input} placeholder="Phone Number" />
              <textarea style={styles.textarea} placeholder="Tell us about your property needs…" rows={4} />
              <button style={styles.btnPrimary} className="cta-btn">
                Send Message →
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={styles.footer}>
        <div style={styles.footerInner}>
          <span style={styles.footerLogo}>
            <span style={styles.logoV}>V</span>alington
          </span>
          <p style={styles.footerTagline}>Premium Real Estate Solutions in Abuja.</p>
          <p style={styles.footerCopy}>© 2026 Valington Homes &amp; Properties Ltd. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

/* ─── STYLES ─────────────────────────────────────────── */
const gold = "#C9A84C";
const dark = "#0E0E0E";
const cream = "#F5F0E8";
const charcoal = "#1A1A1A";

const styles = {
  root: { fontFamily: "'Georgia', serif", color: dark, background: cream, overflowX: "hidden" },

  // NAV
  nav: { position: "fixed", top: 0, left: 0, right: 0, zIndex: 100, padding: "1.2rem 2rem", transition: "all 0.3s ease", background: "transparent" },
  navScrolled: { background: "rgba(14,14,14,0.97)", backdropFilter: "blur(12px)", boxShadow: "0 2px 24px rgba(0,0,0,0.4)" },
  navInner: { maxWidth: 1200, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between" },
  logo: { fontSize: "1.5rem", fontWeight: "700", color: "#fff", textDecoration: "none", letterSpacing: "0.04em" },
  logoV: { color: gold },
  navLinks: { display: "flex", alignItems: "center", gap: "2rem" },
  navLink: { color: "rgba(255,255,255,0.8)", textDecoration: "none", fontSize: "0.9rem", letterSpacing: "0.05em", textTransform: "uppercase" },
  navCta: { background: gold, color: dark, padding: "0.55rem 1.4rem", borderRadius: "2px", textDecoration: "none", fontSize: "0.82rem", fontWeight: "700", letterSpacing: "0.08em", textTransform: "uppercase" },
  burger: { display: "none", background: "none", border: "none", color: "#fff", fontSize: "1.6rem", cursor: "pointer" },
  mobileMenu: { display: "flex", flexDirection: "column", gap: "1rem", paddingTop: "1rem", borderTop: "1px solid rgba(255,255,255,0.1)", marginTop: "1rem" },
  mobileLink: { color: "rgba(255,255,255,0.85)", textDecoration: "none", fontSize: "1.1rem", letterSpacing: "0.05em" },

  // HERO
  hero: { position: "relative", minHeight: "100vh", display: "flex", alignItems: "center", overflow: "hidden" },
  heroBg: { position: "absolute", inset: 0, backgroundImage: "url(https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1600&q=85)", backgroundSize: "cover", backgroundPosition: "center" },
  heroOverlay: { position: "absolute", inset: 0, background: "linear-gradient(120deg, rgba(14,14,14,0.88) 50%, rgba(14,14,14,0.5) 100%)" },
  heroContent: { position: "relative", zIndex: 2, maxWidth: 700, padding: "0 2rem 0 max(2rem, calc(50vw - 600px))" },
  heroEyebrow: { color: gold, fontSize: "0.82rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "1.2rem" },
  heroH1: { fontSize: "clamp(2.8rem, 6vw, 5rem)", fontWeight: "400", color: "#fff", lineHeight: 1.1, marginBottom: "1.5rem", fontStyle: "italic" },
  heroAccent: { color: gold, fontStyle: "normal", fontWeight: "700" },
  heroSub: { color: "rgba(255,255,255,0.7)", fontSize: "1.1rem", lineHeight: 1.7, maxWidth: 520, marginBottom: "2.5rem" },
  heroCtas: { display: "flex", gap: "1.2rem", flexWrap: "wrap" },
  heroScroll: { position: "absolute", bottom: "2.5rem", left: "50%", transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center", gap: "0.5rem", zIndex: 2 },
  scrollDot: { width: 8, height: 8, borderRadius: "50%", background: gold, display: "block" },
  scrollText: { color: "rgba(255,255,255,0.5)", fontSize: "0.7rem", letterSpacing: "0.2em", textTransform: "uppercase" },

  // STATS
  statsStrip: { background: dark, display: "flex", justifyContent: "center", gap: 0, flexWrap: "wrap" },
  stat: { flex: "1 1 160px", display: "flex", flexDirection: "column", alignItems: "center", padding: "2rem 1.5rem", borderRight: "1px solid rgba(255,255,255,0.07)" },
  statValue: { fontSize: "2rem", fontWeight: "700", color: gold },
  statLabel: { fontSize: "0.78rem", color: "rgba(255,255,255,0.5)", letterSpacing: "0.12em", textTransform: "uppercase", marginTop: 4 },

  // SECTIONS
  section: { padding: "6rem 2rem" },
  sectionInner: { maxWidth: 1200, margin: "0 auto" },
  eyebrow: { color: gold, fontSize: "0.78rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.8rem" },
  eyebrowLight: { color: gold, fontSize: "0.78rem", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "0.8rem" },
  h2: { fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: "400", fontStyle: "italic", marginBottom: "3rem", color: dark },
  h2Light: { fontSize: "clamp(2rem, 4vw, 3rem)", fontWeight: "400", fontStyle: "italic", marginBottom: "3rem", color: "#fff" },

  // PROPERTY CARDS
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "2rem" },
  card: { background: "#fff", borderRadius: "4px", overflow: "hidden", boxShadow: "0 4px 24px rgba(0,0,0,0.08)" },
  cardImg: { height: 220, backgroundSize: "cover", backgroundPosition: "center", position: "relative" },
  cardTag: { position: "absolute", top: 16, left: 16, color: "#fff", fontSize: "0.72rem", fontWeight: "700", letterSpacing: "0.1em", textTransform: "uppercase", padding: "0.3rem 0.8rem", borderRadius: "2px" },
  cardBody: { padding: "1.5rem" },
  cardLocation: { fontSize: "0.8rem", color: "#888", marginBottom: "0.3rem" },
  cardTitle: { fontSize: "1.2rem", fontWeight: "600", marginBottom: "0.5rem" },
  cardPrice: { fontSize: "1.3rem", color: gold, fontWeight: "700", marginBottom: "1rem" },
  cardMeta: { display: "flex", gap: "1rem", fontSize: "0.82rem", color: "#555", marginBottom: "1.2rem", flexWrap: "wrap" },
  cardBtn: { background: "none", border: `1.5px solid ${dark}`, padding: "0.55rem 1.2rem", fontSize: "0.82rem", fontWeight: "700", letterSpacing: "0.08em", cursor: "pointer", textTransform: "uppercase", width: "100%" },

  // SERVICES
  servicesBg: { background: charcoal, padding: "6rem 2rem" },
  servGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: "1.5rem" },
  servCard: { border: "1px solid rgba(255,255,255,0.1)", padding: "2.5rem 2rem", cursor: "default", transition: "border-color 0.3s, transform 0.3s" },
  servCardActive: { borderColor: gold, transform: "translateY(-4px)" },
  servIcon: { fontSize: "1.8rem", display: "block", marginBottom: "1.2rem", color: gold },
  servTitle: { fontSize: "1.05rem", fontWeight: "700", color: "#fff", marginBottom: "0.8rem", letterSpacing: "0.02em" },
  servDesc: { fontSize: "0.88rem", color: "rgba(255,255,255,0.55)", lineHeight: 1.7 },

  // ABOUT
  aboutGrid: { maxWidth: 1200, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem", alignItems: "center" },
  aboutImgWrap: { position: "relative" },
  aboutImg: { height: 520, backgroundImage: "url(https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&q=80)", backgroundSize: "cover", backgroundPosition: "center", borderRadius: "2px" },
  aboutBadge: { position: "absolute", bottom: -24, right: -24, background: gold, color: dark, padding: "1.5rem 2rem", display: "flex", flexDirection: "column", alignItems: "center" },
  badgeNum: { fontSize: "2.5rem", fontWeight: "800", lineHeight: 1 },
  badgeTxt: { fontSize: "0.75rem", fontWeight: "600", letterSpacing: "0.1em", textTransform: "uppercase", marginTop: 4 },
  aboutText: { paddingLeft: "1rem" },
  bodyText: { fontSize: "1rem", color: "#444", lineHeight: 1.8, marginBottom: "1.2rem" },

  // CONTACT
  contactBg: { background: "#0E0E0E", padding: "6rem 2rem" },
  contactGrid: { display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: "4rem", alignItems: "start", maxWidth: 1000, margin: "0 auto" },
  contactInfo: { display: "flex", flexDirection: "column", gap: "2rem" },
  contactItem: { display: "flex", gap: "1.2rem", alignItems: "flex-start" },
  contactIcon: { fontSize: "1.4rem", flexShrink: 0 },
  contactLabel: { display: "block", color: gold, fontSize: "0.78rem", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: "0.3rem" },
  contactVal: { color: "rgba(255,255,255,0.65)", fontSize: "0.95rem", lineHeight: 1.7, margin: 0 },
  contactForm: { display: "flex", flexDirection: "column", gap: "1rem" },
  input: { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", padding: "0.9rem 1.2rem", fontSize: "0.95rem", borderRadius: "2px", outline: "none", fontFamily: "inherit" },
  textarea: { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.12)", color: "#fff", padding: "0.9rem 1.2rem", fontSize: "0.95rem", borderRadius: "2px", outline: "none", resize: "vertical", fontFamily: "inherit" },

  // BUTTONS
  btnPrimary: { display: "inline-block", background: gold, color: dark, padding: "0.85rem 2rem", fontSize: "0.85rem", fontWeight: "700", letterSpacing: "0.1em", textTransform: "uppercase", textDecoration: "none", borderRadius: "2px", border: "none", cursor: "pointer" },
  btnGhost: { display: "inline-block", border: "1.5px solid rgba(255,255,255,0.4)", color: "#fff", padding: "0.85rem 2rem", fontSize: "0.85rem", fontWeight: "600", letterSpacing: "0.08em", textTransform: "uppercase", textDecoration: "none", borderRadius: "2px" },

  // FOOTER
  footer: { background: "#060606", padding: "3rem 2rem", textAlign: "center" },
  footerInner: { maxWidth: 600, margin: "0 auto" },
  footerLogo: { fontSize: "1.8rem", fontWeight: "700", color: "#fff" },
  footerTagline: { color: "rgba(255,255,255,0.35)", fontSize: "0.85rem", marginTop: "0.5rem" },
  footerCopy: { color: "rgba(255,255,255,0.2)", fontSize: "0.75rem", marginTop: "1rem" },
};

const css = `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html { scroll-behavior: smooth; }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(28px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes pulse {
    0%,100% { transform: scaleY(1); opacity: 1; }
    50%      { transform: scaleY(2.4); opacity: 0.5; }
  }

  .fade-up { animation: fadeUp 0.9s ease both; }
  .delay-1 { animation-delay: 0.1s; }
  .delay-2 { animation-delay: 0.3s; }
  .delay-3 { animation-delay: 0.5s; }
  .delay-4 { animation-delay: 0.7s; }
  .delay-5 { animation-delay: 1.1s; }
  .scroll-dot { animation: pulse 2s ease infinite; }

  .nav-link:hover { color: #C9A84C !important; }
  .cta-btn:hover  { opacity: 0.88; transform: translateY(-1px); transition: all 0.2s; }
  .ghost-btn:hover { border-color: #C9A84C; color: #C9A84C; transition: all 0.2s; }
  .property-card:hover { box-shadow: 0 12px 40px rgba(0,0,0,0.15); transform: translateY(-4px); transition: all 0.3s; }
  .card-btn:hover { background: #0E0E0E; color: #fff; }
  .serv-card:hover { border-color: #C9A84C; transform: translateY(-4px); }

  @media (max-width: 768px) {
    nav div[style*="navLinks"] { display: none !important; }
    button[style*="burger"] { display: block !important; }
    .about-grid { grid-template-columns: 1fr !important; }
    .contact-grid { grid-template-columns: 1fr !important; }
  }
`;
